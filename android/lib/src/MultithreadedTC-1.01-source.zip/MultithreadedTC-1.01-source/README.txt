For more information about MultithreadedTC, visit 
http://www.cs.umd.edu/projects/PL/multithreadedtc/

To use this library, you need JUnit (3.8 or 4.*). Get it at 
http://www.junit.org

MultithreadedTC is released under the BSD License,
http://www.opensource.org/licenses/bsd-license.php