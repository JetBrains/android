The jar file MultithreadedTC-XXX-jdk14.jar is compiled for JDK 1.4 and requires all the libraries 
distributed with Retrotranslator (http://retrotranslator.sourceforge.net/)
