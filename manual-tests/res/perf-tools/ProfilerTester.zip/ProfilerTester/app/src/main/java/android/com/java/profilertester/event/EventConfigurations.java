package android.com.java.profilertester.event;

public class EventConfigurations {
    public  enum ActionNumber {
        BASIC_EVENTS,
        TYPE_WORDS,
        SWITCH_ACTIVITY
    }
}
