Icons
=====

These icons, if not specified otherwise, are used from https://simpleicons.org/ under `Creative Commons Zero v1.0 Universal` 
and exported to AVDs.

Medium is from their site: https://medium.design/logos-and-brand-guidelines-f1a01a733592

Imgur is from [Wikipedia](https://commons.wikimedia.org/wiki/File:Imgur_icon.svg), which was in turn adapted from their logo kit.

Uplabs was hand traced by me
